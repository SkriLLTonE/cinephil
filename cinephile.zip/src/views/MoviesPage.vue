<template>
    <div>
        Movie
    </div>
</template>

<script setup>

</script>

<style lang="scss" scoped></style>