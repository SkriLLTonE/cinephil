<template>
    <div class="main">
        <Upcoming />
        
    </div>
</template>

<script setup>
import Upcoming from '@/components/Upcoming/Upcoming.vue'
</script>

<style lang="scss" scoped></style>